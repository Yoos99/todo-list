import './list.css';
import List from './List';

export default function PostList() {
  return (
    <ul className="post-list mw">
      <List />
      <List />
      <List />
    </ul>
  );
}
