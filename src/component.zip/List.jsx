import './List.css';

export default function List() {
  return (
    <li className="list">
      <p>여행지 명칭</p>
      <i className="fa-regular fa-trash-can"></i>
    </li>
  );
}
