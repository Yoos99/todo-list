import './Header.css';

export default function Header() {
  return (
    <h1 className="header">
      <i className="fa-solid fa-rocket"></i>
      <strong>가자</strong>
      <strong>여행</strong>
    </h1>
  );
}
