import './TotalCount.css';

export default function TotalCount() {
  return (
    <div className="count mw">
      <strong>count</strong>
      <span>0</span>
    </div>
  );
}
